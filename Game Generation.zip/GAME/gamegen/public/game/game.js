window.onload = function () {
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");
  canvas.width = 480;
  canvas.height = 640;
  document.body.appendChild(canvas);

  context.fillStyle = "#000";
  context.fillRect(0, 0, canvas.width, canvas.height);

  context.font = "20px Arial";
  context.fillStyle = "#fff";
  context.fillText("Flappy Bird Placeholder", 120, 320);
};
