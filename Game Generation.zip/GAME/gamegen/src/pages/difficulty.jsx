import React, { useState } from "react";

const Difficulty = () => {
  const [level, setLevel] = useState("medium");

  const handleChange = (e) => {
    setLevel(e.target.value);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h2 className="text-3xl font-bold mb-6">Select Difficulty</h2>

      <div className="flex flex-col gap-4 max-w-sm">
        {["easy", "medium", "hard"].map((opt) => (
          <label key={opt} className="flex items-center gap-3">
            <input
              type="radio"
              value={opt}
              checked={level === opt}
              onChange={handleChange}
              className="accent-green-500"
            />
            <span className="capitalize text-lg">{opt}</span>
          </label>
        ))}
      </div>

      <div className="mt-6">
        <p className="text-green-400">Selected difficulty: {level.toUpperCase()}</p>
      </div>
    </div>
  );
};

export default Difficulty;
