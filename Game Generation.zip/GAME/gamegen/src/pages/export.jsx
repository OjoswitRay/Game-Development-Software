import React from "react";

const Export = () => {
  const handleExport = () => {
    // This assumes game files are in /public/game/
    const zip = new JSZip();
    zip.file("game.js", fetch("/game/game.js").then(res => res.text()));
    zip.generateAsync({ type: "blob" }).then((blob) => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "custom-game.zip";
      a.click();
      URL.revokeObjectURL(url);
    });
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6 text-center">
      <h2 className="text-3xl font-bold mb-4">Export Your Game</h2>
      <p className="mb-6">
        Click below to generate and download your custom HTML5 game!
      </p>
      <button
        onClick={handleExport}
        className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded text-lg"
      >
        Export Game ZIP
      </button>
    </div>
  );
};

export default Export;
