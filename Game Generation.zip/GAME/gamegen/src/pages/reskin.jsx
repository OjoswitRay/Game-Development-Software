import React from "react";

const Reskin = () => {
  return (
    <div className="min-h-screen p-6 bg-gray-900 text-white">
      <h2 className="text-3xl font-bold mb-4">Reskin Your Game</h2>

      <form className="grid gap-4 max-w-lg">
        <div>
          <label className="block mb-1">Select Background</label>
          <input type="file" accept="image/*" className="w-full bg-gray-800 p-2 rounded" />
        </div>

        <div>
          <label className="block mb-1">Select Bird</label>
          <input type="file" accept="image/*" className="w-full bg-gray-800 p-2 rounded" />
        </div>

        <div>
          <label className="block mb-1">Select Pipe</label>
          <input type="file" accept="image/*" className="w-full bg-gray-800 p-2 rounded" />
        </div>

        <button
          type="submit"
          className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded"
        >
          Apply Skins
        </button>
      </form>
    </div>
  );
};

export default Reskin;
