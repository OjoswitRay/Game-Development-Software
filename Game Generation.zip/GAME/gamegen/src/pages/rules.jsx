import React from "react";

const Rules = () => {
  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h2 className="text-3xl font-bold mb-4">How to Use GameGen</h2>
      <ul className="list-disc pl-6 space-y-3 text-lg">
        <li>Navigate to <strong>Reskin</strong> to upload your custom assets.</li>
        <li>Choose your game's difficulty under the <strong>Difficulty</strong> tab.</li>
        <li>Play and test your game in the <strong>Home</strong> section.</li>
        <li>Once ready, go to <strong>Export</strong> to download your game files.</li>
        <li>No coding required — everything is handled visually!</li>
      </ul>
    </div>
  );
};

export default Rules;
