import React from "react";
import { Link } from "react-router-dom";
import { Home, Paintbrush, Settings, Info, Mail, Download } from "lucide-react";

const Navbar = () => {
  return (
    <nav className="bg-gray-800 p-4 shadow-md text-white flex justify-between items-center">
      <h1 className="text-2xl font-bold text-yellow-400">🎮 GameGen</h1>
      <div className="flex gap-6">
        <Link to="/" className="hover:text-yellow-400 flex items-center gap-1">
          <Home size={18} /> Home
        </Link>
        <Link to="/reskin" className="hover:text-yellow-400 flex items-center gap-1">
          <Paintbrush size={18} /> Reskin
        </Link>
        <Link to="/difficulty" className="hover:text-yellow-400 flex items-center gap-1">
          <Settings size={18} /> Difficulty
        </Link>
        <Link to="/rules" className="hover:text-yellow-400 flex items-center gap-1">
          <Info size={18} /> Rules
        </Link>
        <Link to="/contact" className="hover:text-yellow-400 flex items-center gap-1">
          <Mail size={18} /> Contact
        </Link>
        <Link to="/export" className="hover:text-yellow-400 flex items-center gap-1">
          <Download size={18} /> Export
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
